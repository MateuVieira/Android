package br.com.alura.example.agenda.ui.activity;

interface ConstantesActivities {

    String TITLE_APPBAR_EDITA = "Edita aluno";
    String TITLE_APPBAR_NOVO_ALUNO = "Novo aluno";
    String TITLE_APPBAR_AGENDA = "Agenda";
    String CHAVE_ALUNO = "aluno";
}
